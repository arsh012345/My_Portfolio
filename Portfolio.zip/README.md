[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/B4fMgvAU)
## The final project will be due on Thursday, April 25, 2024 @ 11:59pm.

## Final Project outline

In the Final Project, your goal will be to build one of the following:

- A personal site for yourself
- A portfolio site for yourself

A personal site might include information about you, a blog, a resume page or information about your hobbies or pasttimes. A portfolio site focuses more on your work and your resume.

If you choose to do a portfolio site, you must include at least 3 pieces of work. You will need a page to browse all work and a page to show a single piece of work.

If you choose to include a blog page, you will need to include a page to browse posts and a single post page (you do not need to include all the secondary pages, such as search results, category listings or similar).

## Make sure there is something for me to grade!

If you like the idea of a contact page that is just your email address at the top of the window, that might be your preference but it doesn't give me much to grade! Make sure your pages have layouts, images and any other type of content. 

## Requirements for the project:

- Five pages minimum
- Must include text, images and icons (can include video or other media if you wish)
- Must include real content (no dummy copy or lorem ipsum)
- You may choose to use TailwindCSS if you prefer, otherwise you should use vanilla (regular) CSS
- There is no requirement to use JavaScript, but you may use small amounts if it serves a valid purpose

**IMPORTANT**: This is NOT a project you can complete in a single day. You will get a very poor grade if you attempt to complete this project on the day it is due!
